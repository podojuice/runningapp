package com.example.runningapplication.data.model

data class User(
    var uid: String? = null,
    var email: String? = null,
    var password: String? = null
)